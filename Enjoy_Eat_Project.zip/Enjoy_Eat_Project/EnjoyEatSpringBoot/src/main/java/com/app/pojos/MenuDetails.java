package com.app.pojos;

public class MenuDetails {
	
	Integer menuId;
Integer quantity;
public Integer getMenuId() {
	return menuId;
}
public void setMenuId(Integer menuId) {
	this.menuId = menuId;
}
public Integer getQuantity() {
	return quantity;
}
public void setQuantity(Integer quantity) {
	this.quantity = quantity;
}
}