package com.app.pojos;

import java.util.Map;

public class CartDetails {
	
	private Integer  customerId;
	private Map<Integer,Integer>  menuQuantity;
	private Integer branchId;
	
	
}
