import React from "react";

const Footer = () => {
    return (
        <div>
           <h3> Visit Again !! </h3>
        </div>
    )
}

export default Footer;