import React from "react";
import "./nonvegetarian.css"
const Nonvegetarian=()=>{
    return(
        <div>
            This is Non-vegetarian
        </div>
    )
}

export default Nonvegetarian;